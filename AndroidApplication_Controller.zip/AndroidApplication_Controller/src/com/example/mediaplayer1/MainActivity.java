package com.example.mediaplayer1;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.Socket;
import java.util.concurrent.ExecutionException;
import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener,
		OnItemClickListener {

	public TextView songName;
	private SeekBar seekbar;
	private ImageButton playButton, pauseButton, stopButton, forwardButton, reverseButton;
	private EditText text;
	private Button add;
	private ListView Displaylist;
	public static int oneTimeOnly = 0;
	private String list[] = new String[100];

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		songName = (TextView) findViewById(R.id.textView4);
		Displaylist = (ListView) findViewById(R.id.list);
		this.Displaylist.setOnItemClickListener(this);
		playButton = (ImageButton) findViewById(R.id.imageButton1);
		pauseButton = (ImageButton) findViewById(R.id.imageButton2);
		forwardButton = (ImageButton) findViewById(R.id.imageButton3);
		reverseButton = (ImageButton) findViewById(R.id.imageButton4);
		stopButton = (ImageButton) findViewById(R.id.ImageButton05);
		add = (Button) findViewById(R.id.button1);
		//text = (EditText) findViewById(R.id.selection);

		String[] Playlist = new String[8];
		Playlist[0] = "movies";
		Playlist[1] = "songs";
		Playlist[2] = "eminem-songs";
		Playlist[3] = "katyperry-songs";
		Playlist[4] = "mileycyrus-songs";
		Playlist[5] = "jackiechan-movies";
		Playlist[6] = "arnold-movies";
		Playlist[7] = "decaprio-movies";
		
		ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,Playlist);
		final AutoCompleteTextView av = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView1);
		av.setAdapter(adapter);
		add.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				final String data = av.getText().toString();
				System.out.println("test");
				SearchFilesTask l = new SearchFilesTask();

				l.execute(data);
				try {
					System.out.println(l.get());
					final ArrayAdapter<String> ap = new ArrayAdapter<String>(
							MainActivity.this,
							android.R.layout.simple_list_item_1,
							android.R.id.text1, l.get());
					Displaylist.setAdapter(ap);

				} catch (InterruptedException | ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
/*----------------------------Play Button------------------------------------------------------*/
	playButton.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {

			final String data = "play";
			System.out.println("Entered in playbutton");
			SendToRenderer p1 = new SendToRenderer();

			p1.execute(data);
			try {
				System.out.println(p1.get());
				
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	});
	
/*------------------------------Pause Button----------------------------------------------------*/
	pauseButton.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			final String data = "pause";
			System.out.println("Entered in pause button");
			SendToRenderer p2 = new SendToRenderer();
			p2.execute(data);
			try {
				System.out.println(p2.get());
				
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//pauseButton.setEnabled(false);
			//stopButton.setEnabled(false);
			//playButton.setEnabled(true);
		}
	});

/*------------------------------Stop Button----------------------------------------------------*/
	stopButton.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			final String data = "stop";
			System.out.println("Entered in stop button");
			SendToRenderer p3 = new SendToRenderer();
			p3.execute(data);
			try {
				System.out.println(p3.get());
				
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//pauseButton.setEnabled(false);
			//stopButton.setEnabled(false);
			//playButton.setEnabled(true);
		}
	});
	/*------------------------------Forward Button----------------------------------------------------*/
	forwardButton.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			final String data = "forward";
			System.out.println("Entered in Forward button");
			SendToRenderer p4 = new SendToRenderer();
			p4.execute(data);
			try {
				System.out.println(p4.get());
				
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//pauseButton.setEnabled(false);
			//stopButton.setEnabled(false);
			//playButton.setEnabled(true);
		}
	});
	/*------------------------------Reverse Button----------------------------------------------------*/
	reverseButton.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			final String data = "reverse";
			System.out.println("Entered in reverse button");
			SendToRenderer p5 = new SendToRenderer();
			p5.execute(data);
			try {
				System.out.println(p5.get());
				
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/*pauseButton.setEnabled(false);
			stopButton.setEnabled(false);
			playButton.setEnabled(true);*/
		}
	});
}
//--------------------------------------------------------------------------------------------------------
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Object o = parent.getItemAtPosition(position);
        String sendName = o.toString();
        songName.setText(sendName);
		new SendToRenderer().execute(sendName);      
	}
//------------------------------------------------------------------------------------------------------
	class SearchFilesTask extends AsyncTask<String, String[], String[]> {
		private ProgressDialog pd;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			pd = ProgressDialog.show(MainActivity.this, "", "Loading...");
		}

		@Override
		protected void onPostExecute(String[] result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			pd.dismiss();
		}

		protected String[] doInBackground(String... args) {
			String[] SendtoListView = null;
			try {
				// Log.d(this.getClass().getName(), "Starting1: " + args[0]);
				System.out.println("1st line");
				Socket socket = new Socket("192.168.1.71", 9633);
				// 1st send message to server
				PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
				printWriter.println(args[0]);
				// 2nd read and display response from server
				BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(socket.getInputStream()));
				String data1 = bufferedReader.readLine();
				String criteria1 = ",";
				String[] strarr1 = data1.split(criteria1);
				SendtoListView = strarr1;
				
				socket.close();
				return SendtoListView;
			} catch (Exception e) {
				System.out.println("Exception in listenSocket " + e);
			}
			return SendtoListView;
		}
	}
//------------------------------------------------------------------------------------------------------------	
	class SendToRenderer extends AsyncTask<String, String, String> {

	    private Exception exception;
	    String a= "abc";

	    protected  String doInBackground(String... urls) {
	    	try {
				 System.out.println("Lemme Try to connect Renderer");
				 Socket socket = new Socket("192.168.1.113", 9666);
	             System.out.println("Connected to renderer...");
	             //1st send message to renderer
	             BufferedReader inFromUser = new BufferedReader(new StringReader(urls[0]));
	             DataOutputStream outToRenderer = new DataOutputStream(socket.getOutputStream());
	             String sentence;
	             sentence = inFromUser.readLine();
	             outToRenderer.writeBytes(sentence + '\n');
	             return a;
	            }
	     
	catch(Exception e) {
		System.out.println(e);
				}
	    	 return a;
	    }

	}
//------------------------------------------------------------------------------------------------------------
}
	